package com.example.myapplication


import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.data.NetRep

class ViewNetModelFactory(private val netRep: NetRep) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ViewNetModel::class.java)) {
            return ViewNetModel(netRep) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
package com.example.myapplication.data

import com.example.myapplication.model.Post
import com.example.myapplication.api.NetApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class NetRep {

    private val netApi = NetApi.create()

    fun getPosts(): Flow<List<Post>> {
        return flow {
            val posts = netApi.getPosts()
            emit(posts)
        }
    }

    fun updatePost(post: Post): Flow<Post> {
        return flow {
            val updatedPost = netApi.updatePost(post.id, post)
            emit(updatedPost)
        }
    }
}